package com.project.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UserRequest {
    @NotBlank (message = "Name is required")
    private String name;

    @NotBlank (message = "Email is required")
    @Email(message = "Enter valid email")
    private String email;

    @NotBlank (message = "Password is required")
    @Size(message = "password must be at least 6 charecter" , min = 6)
    private String password;

    @NotBlank (message = "Role is required")
    private String role;

    public UserRequest(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
